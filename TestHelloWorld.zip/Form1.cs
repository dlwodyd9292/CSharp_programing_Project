﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestHelloWorld
{
    public partial class sum : Form
    {
        int cnt = 0, playWin = 0, playLose = 0;

        public sum()
        {
            InitializeComponent();
        }

        private void BtnHello_Click(object sender, EventArgs e)
        {   
            MessageBox.Show("Hello World~!!");
        }

        private void BtnChange_Click(object sender, EventArgs e)
        {
            int a = 5;
            float b = 0;
            b = (float)a;

            BtnHello.Text = "안녕ㅎㅎ";
            MessageBox.Show(b.ToString());
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
           txtResult.Text = (Convert.ToInt32(txtSuOne.Text) + Convert.ToInt32(txtSuTwo.Text)).ToString();
        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            txtResult.Text = (Convert.ToInt32(txtSuOne.Text) - Convert.ToInt32(txtSuTwo.Text)).ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            txtResult.Text = (Convert.ToDouble(txtSuOne.Text) / Convert.ToDouble(txtSuTwo.Text)).ToString();
        }

        private void BtnMulti_Click(object sender, EventArgs e)
        {

            txtResult.Text = (Convert.ToInt32(txtSuOne.Text) * Convert.ToInt32(txtSuTwo.Text)).ToString();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtSuOne.Text = " ";
            txtSuTwo.Text = " ";
            txtSuThree.Text = " ";
            txtResult.Text = " ";
            txtSum.Text = " ";
            txtAvg.Text = " ";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(txtSuOne.Text) > Convert.ToInt32(txtSuTwo.Text))
                txtResult.Text = "수 1의 " + Convert.ToInt32(txtSuOne.Text).ToString() + "이(가) 큰 수 입니다.";
            else if (Convert.ToInt32(txtSuOne.Text) < Convert.ToInt32(txtSuTwo.Text))
                txtResult.Text = "수 2의 " + Convert.ToInt32(txtSuTwo.Text).ToString() + "이(가) 큰 수 입니다.";
            else if (Convert.ToInt32(txtSuOne.Text) == Convert.ToInt32(txtSuTwo.Text))
                txtResult.Text = "두 수는 같습니다.";
        }

        private void BtnSum_Click(object sender, EventArgs e)
        {
            int sum = 0;

            for (int i = Convert.ToInt32(txtSuOne.Text); i <= Convert.ToInt32(txtSuTwo.Text); i++)
              sum += i;

            txtResult.Text = sum.ToString();
        }

        private void BtnSumJJak_Click(object sender, EventArgs e)
        {
            int sum = 0;

            for (int i = Convert.ToInt32(txtSuOne.Text); i <= Convert.ToInt32(txtSuTwo.Text); i++)
               
                if(i % 2 == 0) sum += i;

            txtResult.Text = sum.ToString();
        }

        private void BtnForEach_Click(object sender, EventArgs e)
        {
     //       string[] color = { "Read", "Green", "Blue", "Yellow", "Puple", "Magenta", "Velet" };

    //            foreach( string s in color ) Console.WriteLine(s);

            double d = Math.PI;
            int idata = 5;
            try
            {
                Console.WriteLine("1) {0, -5}, {1,5}, {2,5}", 1.2, 1.2, 123.45);
                Console.WriteLine("2) {0}", d);
                Console.WriteLine("3) {0:C}", d);
                Console.WriteLine("4) {0:E}", d);
                Console.WriteLine("5) {0:F}", d);
                Console.WriteLine("6) {0:G}", d);
                Console.WriteLine("7) {0:P}", d);
                Console.WriteLine("8) {0:R}", d);
                Console.WriteLine("9) {0:X}", 255);
                Console.WriteLine($"test--> {idata}");
            }
            catch
            {
                MessageBox.Show("Erorr");
            }
        }

        private void BtnScore_Click(object sender, EventArgs e)
        {
            txtResult.Text = Convert.ToString(Convert.ToInt32(txtSuOne.Text) +  Convert.ToInt32(txtSuTwo.Text) + Convert.ToInt32(txtSuThree.Text));

            int score = Convert.ToInt32(txtResult.Text);

            double scoreAvg = (double)(score / 3.0);

            txtAvg.Text = Convert.ToString(scoreAvg);

            if (scoreAvg > 90) txtSum.Text = "수";
            else if (scoreAvg <= 90 && scoreAvg > 80) txtSum.Text = "우";
            else if (scoreAvg <= 80 && scoreAvg > 70) txtSum.Text = "미";
            else if (scoreAvg <= 70 && scoreAvg > 60) txtSum.Text = "양";
            else if (scoreAvg <= 60 && scoreAvg > 50) txtSum.Text = "가";
        }

        private void btnGuGu_Click(object sender, EventArgs e)
        {
            lstBguGu.Items.Clear();

            int input = Convert.ToInt32(txtDanInput.Text);

            for(int i = 1; i < 10; i++)
            {
                int value = i * input;
                lstBguGu.Items.Add(input + " X " + i + " = " + value);
            }
        }

        private void BtnGameStart_Click(object sender, EventArgs e)
        {
            int strike = 0, ball = 0;

            cnt++;

            int inputOne = Convert.ToInt32(txtInputOne.Text);
            int inputTwo = Convert.ToInt32(txtInputTwo.Text);
            int inputThree = Convert.ToInt32(txtInputThree.Text);

            int iRndOne = Convert.ToInt32(txtOutputOne.Text);
            int iRndTwo = Convert.ToInt32(txtOutputTwo.Text);
            int iRndThree = Convert.ToInt32(txtOutputThree.Text);

            if (inputOne == iRndOne) strike++; 
            if (inputTwo == iRndTwo) strike++; 
            if (inputThree == iRndThree) strike++;

            if (inputOne == iRndTwo || inputOne == iRndThree) ball++;
            if (inputTwo == iRndOne || inputTwo == iRndThree) ball++;
            if (inputThree == iRndOne || inputThree == iRndTwo) ball++;

            if (strike == 3)
            {
                MessageBox.Show("****You WIN****");
                playWin++;

                btnRandom.Enabled = true;
                BtnGameStart.Enabled = false;
            }
            else if (cnt >= 10)
            {
                MessageBox.Show("You LOSE");
                playLose++;

                btnRandom.Enabled = true;
                BtnGameStart.Enabled = false;
            }

            lstBaseballResult.Items.Add(" STRIKE : " + strike + " BALL : " + ball);
            txtCnt.Text = Convert.ToString(cnt);
            txtScore.Text = (Convert.ToString(playWin) + "승 " + Convert.ToString(playLose) + "패");
        }

        private void btnRandom_Click(object sender, EventArgs e)
        {
            lstBaseballResult.Items.Clear();
            int iRndOne;
            int iRndTwo;
            int iRndThree;

            Random iRnd = new Random();

            while (true)
            {
                iRndOne = iRnd.Next(10);
                iRndTwo = iRnd.Next(10);
                iRndThree = iRnd.Next(10);

                if (iRndOne != iRndTwo && iRndOne != iRndThree && iRndTwo != iRndThree) break;
            }
            txtOutputOne.Text = Convert.ToString(iRndOne);
            txtOutputTwo.Text = Convert.ToString(iRndTwo);
            txtOutputThree.Text = Convert.ToString(iRndThree);

            btnRandom.Enabled = false;
            BtnGameStart.Enabled = true;

            lstBaseballResult.Items.Clear();

            cnt = 0;

            txtInputOne.Focus();
            txtInputOne.Select(0, txtInputOne.Text.Length);
        }
    }
}
