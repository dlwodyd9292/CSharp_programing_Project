﻿
namespace TestHelloWorld
{
    partial class sum
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnHello = new System.Windows.Forms.Button();
            this.BtnChange = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnMinus = new System.Windows.Forms.Button();
            this.BtnDiv = new System.Windows.Forms.Button();
            this.BtnMulti = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSuOne = new System.Windows.Forms.TextBox();
            this.txtSuTwo = new System.Windows.Forms.TextBox();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.BtnSum = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.btnCompare = new System.Windows.Forms.Button();
            this.BtnSumJJak = new System.Windows.Forms.Button();
            this.BtnForEach = new System.Windows.Forms.Button();
            this.txtSuThree = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSum = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnScore = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAvg = new System.Windows.Forms.TextBox();
            this.btnGuGu = new System.Windows.Forms.Button();
            this.lstBguGu = new System.Windows.Forms.ListBox();
            this.txtDanInput = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtInputOne = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtInputTwo = new System.Windows.Forms.TextBox();
            this.txtInputThree = new System.Windows.Forms.TextBox();
            this.txtOutputThree = new System.Windows.Forms.TextBox();
            this.txtOutputTwo = new System.Windows.Forms.TextBox();
            this.txtOutputOne = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lstBaseballResult = new System.Windows.Forms.ListBox();
            this.BtnGameStart = new System.Windows.Forms.Button();
            this.txtCnt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnRandom = new System.Windows.Forms.Button();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnHello
            // 
            this.BtnHello.BackColor = System.Drawing.Color.DarkBlue;
            this.BtnHello.Font = new System.Drawing.Font("맑은 고딕", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BtnHello.ForeColor = System.Drawing.Color.Coral;
            this.BtnHello.Location = new System.Drawing.Point(637, 155);
            this.BtnHello.Name = "BtnHello";
            this.BtnHello.Size = new System.Drawing.Size(131, 86);
            this.BtnHello.TabIndex = 0;
            this.BtnHello.Text = "Hello World";
            this.BtnHello.UseVisualStyleBackColor = false;
            this.BtnHello.Click += new System.EventHandler(this.BtnHello_Click);
            // 
            // BtnChange
            // 
            this.BtnChange.Font = new System.Drawing.Font("맑은 고딕", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BtnChange.Location = new System.Drawing.Point(637, 36);
            this.BtnChange.Name = "BtnChange";
            this.BtnChange.Size = new System.Drawing.Size(131, 90);
            this.BtnChange.TabIndex = 1;
            this.BtnChange.Text = "속성 변경";
            this.BtnChange.UseVisualStyleBackColor = true;
            this.BtnChange.Click += new System.EventHandler(this.BtnChange_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Location = new System.Drawing.Point(404, 45);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(120, 79);
            this.BtnAdd.TabIndex = 2;
            this.BtnAdd.Text = "더하기";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnMinus
            // 
            this.BtnMinus.Location = new System.Drawing.Point(404, 130);
            this.BtnMinus.Name = "BtnMinus";
            this.BtnMinus.Size = new System.Drawing.Size(120, 79);
            this.BtnMinus.TabIndex = 3;
            this.BtnMinus.Text = "빼기";
            this.BtnMinus.UseVisualStyleBackColor = true;
            this.BtnMinus.Click += new System.EventHandler(this.BtnMinus_Click);
            // 
            // BtnDiv
            // 
            this.BtnDiv.Location = new System.Drawing.Point(404, 215);
            this.BtnDiv.Name = "BtnDiv";
            this.BtnDiv.Size = new System.Drawing.Size(120, 79);
            this.BtnDiv.TabIndex = 4;
            this.BtnDiv.Text = "나누기";
            this.BtnDiv.UseVisualStyleBackColor = true;
            this.BtnDiv.Click += new System.EventHandler(this.BtnDiv_Click);
            // 
            // BtnMulti
            // 
            this.BtnMulti.Location = new System.Drawing.Point(404, 300);
            this.BtnMulti.Name = "BtnMulti";
            this.BtnMulti.Size = new System.Drawing.Size(120, 79);
            this.BtnMulti.TabIndex = 5;
            this.BtnMulti.Text = "곱하기";
            this.BtnMulti.UseVisualStyleBackColor = true;
            this.BtnMulti.Click += new System.EventHandler(this.BtnMulti_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(39, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 22);
            this.label1.TabIndex = 6;
            this.label1.Text = "국어";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(39, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 26);
            this.label2.TabIndex = 7;
            this.label2.Text = "영어";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(39, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 29);
            this.label3.TabIndex = 8;
            this.label3.Text = "결과";
            // 
            // txtSuOne
            // 
            this.txtSuOne.Location = new System.Drawing.Point(144, 54);
            this.txtSuOne.Name = "txtSuOne";
            this.txtSuOne.Size = new System.Drawing.Size(154, 25);
            this.txtSuOne.TabIndex = 9;
            // 
            // txtSuTwo
            // 
            this.txtSuTwo.Location = new System.Drawing.Point(144, 155);
            this.txtSuTwo.Name = "txtSuTwo";
            this.txtSuTwo.Size = new System.Drawing.Size(154, 25);
            this.txtSuTwo.TabIndex = 10;
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(144, 208);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(228, 25);
            this.txtResult.TabIndex = 11;
            // 
            // BtnSum
            // 
            this.BtnSum.Location = new System.Drawing.Point(648, 300);
            this.BtnSum.Name = "BtnSum";
            this.BtnSum.Size = new System.Drawing.Size(120, 31);
            this.BtnSum.TabIndex = 12;
            this.BtnSum.Text = "합 구하기";
            this.BtnSum.UseVisualStyleBackColor = true;
            this.BtnSum.Click += new System.EventHandler(this.BtnSum_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(223, 355);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(75, 44);
            this.BtnClear.TabIndex = 13;
            this.BtnClear.Text = "Clear";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // btnCompare
            // 
            this.btnCompare.Location = new System.Drawing.Point(548, 300);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(80, 79);
            this.btnCompare.TabIndex = 14;
            this.btnCompare.Text = "비교";
            this.btnCompare.UseVisualStyleBackColor = true;
            this.btnCompare.Click += new System.EventHandler(this.button2_Click);
            // 
            // BtnSumJJak
            // 
            this.BtnSumJJak.Location = new System.Drawing.Point(648, 337);
            this.BtnSumJJak.Name = "BtnSumJJak";
            this.BtnSumJJak.Size = new System.Drawing.Size(120, 23);
            this.BtnSumJJak.TabIndex = 15;
            this.BtnSumJJak.Text = "합구하기(짝수)";
            this.BtnSumJJak.UseVisualStyleBackColor = true;
            this.BtnSumJJak.Click += new System.EventHandler(this.BtnSumJJak_Click);
            // 
            // BtnForEach
            // 
            this.BtnForEach.Location = new System.Drawing.Point(648, 366);
            this.BtnForEach.Name = "BtnForEach";
            this.BtnForEach.Size = new System.Drawing.Size(120, 23);
            this.BtnForEach.TabIndex = 16;
            this.BtnForEach.Text = "foreachTest";
            this.BtnForEach.UseVisualStyleBackColor = true;
            this.BtnForEach.Click += new System.EventHandler(this.BtnForEach_Click);
            // 
            // txtSuThree
            // 
            this.txtSuThree.Location = new System.Drawing.Point(144, 101);
            this.txtSuThree.Name = "txtSuThree";
            this.txtSuThree.Size = new System.Drawing.Size(154, 25);
            this.txtSuThree.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(39, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 22);
            this.label4.TabIndex = 17;
            this.label4.Text = "수학";
            // 
            // txtSum
            // 
            this.txtSum.Location = new System.Drawing.Point(144, 300);
            this.txtSum.Name = "txtSum";
            this.txtSum.Size = new System.Drawing.Size(228, 25);
            this.txtSum.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(39, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 29);
            this.label5.TabIndex = 19;
            this.label5.Text = "총점";
            // 
            // BtnScore
            // 
            this.BtnScore.Location = new System.Drawing.Point(129, 355);
            this.BtnScore.Name = "BtnScore";
            this.BtnScore.Size = new System.Drawing.Size(75, 44);
            this.BtnScore.TabIndex = 21;
            this.BtnScore.Text = "성적처리";
            this.BtnScore.UseVisualStyleBackColor = true;
            this.BtnScore.Click += new System.EventHandler(this.BtnScore_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(39, 255);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 29);
            this.label6.TabIndex = 23;
            this.label6.Text = "평균";
            // 
            // txtAvg
            // 
            this.txtAvg.Location = new System.Drawing.Point(144, 255);
            this.txtAvg.Name = "txtAvg";
            this.txtAvg.Size = new System.Drawing.Size(228, 25);
            this.txtAvg.TabIndex = 22;
            // 
            // btnGuGu
            // 
            this.btnGuGu.Location = new System.Drawing.Point(961, 12);
            this.btnGuGu.Name = "btnGuGu";
            this.btnGuGu.Size = new System.Drawing.Size(108, 29);
            this.btnGuGu.TabIndex = 24;
            this.btnGuGu.Text = "구구단 출력";
            this.btnGuGu.UseVisualStyleBackColor = true;
            this.btnGuGu.Click += new System.EventHandler(this.btnGuGu_Click);
            // 
            // lstBguGu
            // 
            this.lstBguGu.FormattingEnabled = true;
            this.lstBguGu.ItemHeight = 15;
            this.lstBguGu.Location = new System.Drawing.Point(809, 57);
            this.lstBguGu.Name = "lstBguGu";
            this.lstBguGu.Size = new System.Drawing.Size(257, 334);
            this.lstBguGu.TabIndex = 25;
            // 
            // txtDanInput
            // 
            this.txtDanInput.Location = new System.Drawing.Point(883, 12);
            this.txtDanInput.Name = "txtDanInput";
            this.txtDanInput.Size = new System.Drawing.Size(72, 25);
            this.txtDanInput.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(805, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 22);
            this.label7.TabIndex = 26;
            this.label7.Text = "단수 입력";
            // 
            // txtInputOne
            // 
            this.txtInputOne.Location = new System.Drawing.Point(1178, 16);
            this.txtInputOne.Name = "txtInputOne";
            this.txtInputOne.Size = new System.Drawing.Size(72, 25);
            this.txtInputOne.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(1100, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 22);
            this.label8.TabIndex = 28;
            this.label8.Text = "입력";
            // 
            // txtInputTwo
            // 
            this.txtInputTwo.Location = new System.Drawing.Point(1256, 16);
            this.txtInputTwo.Name = "txtInputTwo";
            this.txtInputTwo.Size = new System.Drawing.Size(72, 25);
            this.txtInputTwo.TabIndex = 30;
            // 
            // txtInputThree
            // 
            this.txtInputThree.Location = new System.Drawing.Point(1334, 16);
            this.txtInputThree.Name = "txtInputThree";
            this.txtInputThree.Size = new System.Drawing.Size(72, 25);
            this.txtInputThree.TabIndex = 31;
            // 
            // txtOutputThree
            // 
            this.txtOutputThree.Location = new System.Drawing.Point(1334, 57);
            this.txtOutputThree.Name = "txtOutputThree";
            this.txtOutputThree.Size = new System.Drawing.Size(72, 25);
            this.txtOutputThree.TabIndex = 35;
            // 
            // txtOutputTwo
            // 
            this.txtOutputTwo.Location = new System.Drawing.Point(1256, 57);
            this.txtOutputTwo.Name = "txtOutputTwo";
            this.txtOutputTwo.Size = new System.Drawing.Size(72, 25);
            this.txtOutputTwo.TabIndex = 34;
            // 
            // txtOutputOne
            // 
            this.txtOutputOne.Location = new System.Drawing.Point(1178, 57);
            this.txtOutputOne.Name = "txtOutputOne";
            this.txtOutputOne.Size = new System.Drawing.Size(72, 25);
            this.txtOutputOne.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(1100, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 22);
            this.label9.TabIndex = 32;
            this.label9.Text = "컴퓨터";
            // 
            // lstBaseballResult
            // 
            this.lstBaseballResult.FormattingEnabled = true;
            this.lstBaseballResult.ItemHeight = 15;
            this.lstBaseballResult.Location = new System.Drawing.Point(1178, 102);
            this.lstBaseballResult.Name = "lstBaseballResult";
            this.lstBaseballResult.Size = new System.Drawing.Size(228, 109);
            this.lstBaseballResult.TabIndex = 36;
            // 
            // BtnGameStart
            // 
            this.BtnGameStart.Location = new System.Drawing.Point(1298, 240);
            this.BtnGameStart.Name = "BtnGameStart";
            this.BtnGameStart.Size = new System.Drawing.Size(108, 29);
            this.BtnGameStart.TabIndex = 37;
            this.BtnGameStart.Text = "결과 확인";
            this.BtnGameStart.UseVisualStyleBackColor = true;
            this.BtnGameStart.Click += new System.EventHandler(this.BtnGameStart_Click);
            // 
            // txtCnt
            // 
            this.txtCnt.Location = new System.Drawing.Point(1178, 240);
            this.txtCnt.Name = "txtCnt";
            this.txtCnt.Size = new System.Drawing.Size(102, 25);
            this.txtCnt.TabIndex = 39;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(1100, 240);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 22);
            this.label10.TabIndex = 38;
            this.label10.Text = "횟수";
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(1298, 275);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(108, 29);
            this.btnRandom.TabIndex = 40;
            this.btnRandom.Text = "난수발생";
            this.btnRandom.UseVisualStyleBackColor = true;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // txtScore
            // 
            this.txtScore.Location = new System.Drawing.Point(1178, 279);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(102, 25);
            this.txtScore.TabIndex = 41;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(1100, 282);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 22);
            this.label11.TabIndex = 42;
            this.label11.Text = "전적";
            // 
            // sum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1426, 601);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.txtCnt);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.BtnGameStart);
            this.Controls.Add(this.lstBaseballResult);
            this.Controls.Add(this.txtOutputThree);
            this.Controls.Add(this.txtOutputTwo);
            this.Controls.Add(this.txtOutputOne);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtInputThree);
            this.Controls.Add(this.txtInputTwo);
            this.Controls.Add(this.txtInputOne);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtDanInput);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lstBguGu);
            this.Controls.Add(this.btnGuGu);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAvg);
            this.Controls.Add(this.BtnScore);
            this.Controls.Add(this.txtSum);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSuThree);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.BtnForEach);
            this.Controls.Add(this.BtnSumJJak);
            this.Controls.Add(this.btnCompare);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnSum);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtSuTwo);
            this.Controls.Add(this.txtSuOne);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnMulti);
            this.Controls.Add(this.BtnDiv);
            this.Controls.Add(this.BtnMinus);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnChange);
            this.Controls.Add(this.BtnHello);
            this.Name = "sum";
            this.Text = "사칙연산";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnHello;
        private System.Windows.Forms.Button BtnChange;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnMinus;
        private System.Windows.Forms.Button BtnDiv;
        private System.Windows.Forms.Button BtnMulti;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSuOne;
        private System.Windows.Forms.TextBox txtSuTwo;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Button BtnSum;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button btnCompare;
        private System.Windows.Forms.Button BtnSumJJak;
        private System.Windows.Forms.Button BtnForEach;
        private System.Windows.Forms.TextBox txtSuThree;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnScore;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAvg;
        private System.Windows.Forms.Button btnGuGu;
        private System.Windows.Forms.ListBox lstBguGu;
        private System.Windows.Forms.TextBox txtDanInput;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtInputOne;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtInputTwo;
        private System.Windows.Forms.TextBox txtInputThree;
        private System.Windows.Forms.TextBox txtOutputThree;
        private System.Windows.Forms.TextBox txtOutputTwo;
        private System.Windows.Forms.TextBox txtOutputOne;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox lstBaseballResult;
        private System.Windows.Forms.Button BtnGameStart;
        private System.Windows.Forms.TextBox txtCnt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.TextBox txtScore;
        private System.Windows.Forms.Label label11;
    }
}

