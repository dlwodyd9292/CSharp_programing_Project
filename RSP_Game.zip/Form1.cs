﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RSP_Game
{
    public partial class Form1 : Form
    {
        int Coin = 0, cnt = -1, box1 = -1, box2 = -1, ComWin = 0, PlyWin = 0, Draw = 0;

        bool GameFlag = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCoin_Click(object sender, EventArgs e)
        {
            Coin += 100;
            txtCoinShow.Text = Convert.ToString(Coin + "원");
            GameFlag = true;

            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtCoinShow.Text = Convert.ToString(Coin + "원");

            label5.Text = Convert.ToString("(사용자 기준) " + PlyWin + "승 " + Draw + "무 " + ComWin + "패");
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            if (GameFlag == true)
            {   
                Random rnd = new Random();

                int num = rnd.Next(0, 3);

                pictureBox2.Image = imageList1.Images[num];

                box2 = num;

                timer1.Stop();

                GameFlag = false;
            }
            else
            {
                MessageBox.Show("동전 100원을 투입하여 주십시오");
            }

            if(box1 == box2)
            { 
                label4.Text = "무승부";
                Draw++;
            }
            else if(box1 == 0 && box2 == 1)
            { //컴퓨터 가위
                label4.Text = "사용자 승리!";
                PlyWin++;
            }
            else if (box1 == 0 && box2 == 2)
            {
                label4.Text = "컴퓨터 승리!";
                ComWin++;
            }
            else if (box1 == 1 && box2 == 0)
            { //컴퓨터 바위
                label4.Text = "컴퓨터 승리!";
                ComWin++;
            }
            else if (box1 == 1 && box2 == 2)
            {
                label4.Text = "사용자 승리!";
                PlyWin++;
            }
            else if (box1 == 2 && box2 == 0)
            { //컴퓨터 보
                label4.Text = "사용자 승리!";
                PlyWin++;
            }
            else if (box1 == 2 && box2 == 1)
            {
                label4.Text = "컴퓨터 승리!";
                ComWin++;
            }

            label5.Text = Convert.ToString("(사용자 기준) " + PlyWin + "승 " + Draw + "무 " + ComWin + "패");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cnt++;
            if (cnt == 3) cnt = 0;
            pictureBox1.Image = imageList1.Images[cnt];

            box1 = cnt;
        }
    }
}
