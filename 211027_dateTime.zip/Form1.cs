﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _211027_dateTime
{
    public partial class Form1 : Form
    {
        DateTime GetStartDateTime;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();

            int num = rnd.Next(4);
            int catchMe = rnd.Next(5);

            if (catchMe == 6)
            {
                button1.Top = 134;
                button1.Left = 314;
                MessageBox.Show("잡혔습니다!");
            }
            else
            {
                switch (num)
                {
                    case 0: //상
                        button1.Top -= button1.Height;
                        break;
                    case 1: //하
                        button1.Top += button1.Height;
                        break;
                    case 2: //좌
                        button1.Left -= button1.Width;
                        break;
                    case 3: //우
                        button1.Left += button1.Width;
                        break;
                }
            }

            if (button1.Top < 0) button1.Top = 134;
            if (button1.Left < 0) button1.Left = 314;
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
 
        }
    }
}
