﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtOne = new System.Windows.Forms.TextBox();
            this.txtTwo = new System.Windows.Forms.TextBox();
            this.txtThree = new System.Windows.Forms.TextBox();
            this.txtFour = new System.Windows.Forms.TextBox();
            this.txtFive = new System.Windows.Forms.TextBox();
            this.txtSix = new System.Windows.Forms.TextBox();
            this.btnRnd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtOne
            // 
            this.txtOne.Location = new System.Drawing.Point(124, 63);
            this.txtOne.Name = "txtOne";
            this.txtOne.Size = new System.Drawing.Size(100, 21);
            this.txtOne.TabIndex = 0;
            // 
            // txtTwo
            // 
            this.txtTwo.Location = new System.Drawing.Point(257, 63);
            this.txtTwo.Name = "txtTwo";
            this.txtTwo.Size = new System.Drawing.Size(100, 21);
            this.txtTwo.TabIndex = 1;
            // 
            // txtThree
            // 
            this.txtThree.Location = new System.Drawing.Point(385, 63);
            this.txtThree.Name = "txtThree";
            this.txtThree.Size = new System.Drawing.Size(100, 21);
            this.txtThree.TabIndex = 2;
            // 
            // txtFour
            // 
            this.txtFour.Location = new System.Drawing.Point(124, 108);
            this.txtFour.Name = "txtFour";
            this.txtFour.Size = new System.Drawing.Size(100, 21);
            this.txtFour.TabIndex = 3;
            // 
            // txtFive
            // 
            this.txtFive.Location = new System.Drawing.Point(257, 108);
            this.txtFive.Name = "txtFive";
            this.txtFive.Size = new System.Drawing.Size(100, 21);
            this.txtFive.TabIndex = 4;
            // 
            // txtSix
            // 
            this.txtSix.Location = new System.Drawing.Point(385, 108);
            this.txtSix.Name = "txtSix";
            this.txtSix.Size = new System.Drawing.Size(100, 21);
            this.txtSix.TabIndex = 5;
            // 
            // btnRnd
            // 
            this.btnRnd.Location = new System.Drawing.Point(530, 63);
            this.btnRnd.Name = "btnRnd";
            this.btnRnd.Size = new System.Drawing.Size(85, 23);
            this.btnRnd.TabIndex = 6;
            this.btnRnd.Text = "발생";
            this.btnRnd.UseVisualStyleBackColor = true;
            this.btnRnd.Click += new System.EventHandler(this.btnRnd_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(682, 284);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 329);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnRnd);
            this.Controls.Add(this.txtSix);
            this.Controls.Add(this.txtFive);
            this.Controls.Add(this.txtFour);
            this.Controls.Add(this.txtThree);
            this.Controls.Add(this.txtTwo);
            this.Controls.Add(this.txtOne);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtOne;
        private System.Windows.Forms.TextBox txtTwo;
        private System.Windows.Forms.TextBox txtThree;
        private System.Windows.Forms.TextBox txtFour;
        private System.Windows.Forms.TextBox txtFive;
        private System.Windows.Forms.TextBox txtSix;
        private System.Windows.Forms.Button btnRnd;
        private System.Windows.Forms.Button button1;
    }
}

