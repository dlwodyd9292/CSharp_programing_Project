﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRnd_Click(object sender, EventArgs e)
        {
            Random rand = new Random();

            int[] Lotto = new int[6];
            TextBox[] LabelLotto = { txtOne, txtTwo, txtThree, txtFour, txtFive, txtSix };

            for (int i = 0; i < 6; i++)
            {
                int Flag = 0;
                do
                {
                    Flag = 0;
                    Lotto[i] = rand.Next(1, 46);

                    for (int k = 0; k < i; k++)
                    {
                        if (Lotto[i] == Lotto[k])
                        {
                            Flag = 1;
                        }
                    }
                } while (Flag == 1);
            }

            for (int i = 0; i < 6; i++)
            {
                LabelLotto[i].Text = Convert.ToString(Lotto[i]);
            }

        }

        void Swap<DataType>(ref DataType x, ref DataType y)
        {
            DataType temp;
            temp = x;
            x = y;
            y = temp;

            Console.WriteLine($" In Swap x --> {x} y --> {y}");
        }

        class MethodOverLoading
        {
            public void SomeThing()
            {
                Console.WriteLine("SomeThing() is called.");
            }
            public void SomeThing(int i)
            {
                Console.WriteLine("SomeThing(int) is called.");
            }
            public void SomeThing(int i, int j)
            {
                Console.WriteLine("SomeThing(int,int) is called.");
            }
            public void SomeThing(double d)
            {
                Console.WriteLine("SomeThing(double) is called.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*            int a = 1;
                        int b = 2;
                        double c = 1.5;
                        double d = 2.5;
                        Console.WriteLine($" Before Swap x --> {a} y --> {b}");
                        Swap<int>(ref a, ref b);
                        Console.WriteLine($" After Swap x --> {a} y --> {b}");

                        Console.WriteLine($" Before Swap x --> {c} y --> {d}");
                        Swap<double>(ref c, ref d);
                        Console.WriteLine($" After Swap x --> {c} y --> {d}");*/

            /*          MethodOverLoading obj = new MethodOverLoading();
                      obj.SomeThing();
                      obj.SomeThing(526);
                      obj.SomeThing(54, 526);
                      obj.SomeThing(5.26);*/

            /*            func aa = new func();
                        func aa2 = new func(1);
                        func aa3 = new func(2, 3);*/

            DerivedClass Child = new DerivedClass();
            BaseClass Parent = new BaseClass();

            Child.MethodB();
            Child.MethodA();
            Parent.MethodB();
        }

        /*        private delegate int MyDelegate(int a, int b);
                int Plus(int a, int b)
                {
                    return a + b;
                }

                int Minus(int a, int b)
                {
                    return a - b;
                }*/

        private delegate void MyDelegate(string text);
        void num_1(string text)
        {
            Console.WriteLine("1번 : {0}", text);
        }

        void num_2(string text)
        {
            Console.WriteLine("2번 : {0}", text);
        }

        void num_3(string text)
        {
            Console.WriteLine("3번 : {0}", text);
        }

        class SimpleThreadApp
        {
            static void ThreadBody()
            {                                               // --- ① 
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine(DateTime.Now.Second + " : " + i);
                    Thread.Sleep(1000);
                }
            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            /*            Fraction f = new Fraction();

                        f.Numerator = 1;
                        int i = f.Numerator + 1;
                        Console.WriteLine(f.ToString());*/
            /*
                        Color c = new Color();
                        c[0] = "WHITE"; c[1] = "RED";
                        c[2] = "YELLOW"; c[3] = "BLUE";
                        c[4] = "BLACK";
                        for (int i = 0; i < 5; i++)
                            Console.WriteLine("Color is " + c[i]);

                         Complex c, c1, c2; 
                        c1 = new Complex(1, 2); 
                        c2 = new Complex(3, 4); 
                        c = c1 + c2; 
                        Console.WriteLine(c1 + " + " + c2 + " = " + c); 

            */
            /*
                        Complex c, c1, c2;
                        c1 = new Complex(1, 2);
                        c2 = new Complex(3, 4);
                        c = c1 + c2;
                        Console.WriteLine(c1 + " + " + c2 + " = " + c);
            */
            /*MyDelegate function;

            function = new MyDelegate(Plus);
            Console.WriteLine(function(3, 4));

            function = new MyDelegate(Minus);
            Console.WriteLine(function(7, 5));*/
            /*
                        MyDelegate dele = new MyDelegate(num_1);
                        dele += new MyDelegate(num_2);
                        dele += new MyDelegate(num_3);

                        dele("사람");

                        dele -= new MyDelegate(num_2);

                        dele("인간");*/

            ThreadStart ts = new ThreadStart(ThreadBody);               // --- ② 
            Thread t = new Thread(ts);                                         // --- ③ 
            Console.WriteLine("*** Start of Main");
            t.Start();                                                                 // --- ④ 
            Console.WriteLine("*** End of Main");

        }
    }

    class func
    {
        public func()
        {
            Console.WriteLine("func 1번");
        }

        public func(int a)
        {
            Console.WriteLine($"Func 2번, a -->{a}");
        }

        public func(int a, int b)
        {
            Console.WriteLine($"Func 3번, a -->{a}. a -->{b}");
        }
    }
    class BaseClass
    {
        int a;
        public void MethodA()
        {
            Console.WriteLine("BaseClass");
        }
        public virtual void MethodB()
        {
            Console.WriteLine("BaseClass MethodB");
        }
    }

    class DerivedClass : BaseClass
    {
        int b;
        public override void MethodB()
        {
            Console.WriteLine("DerivedClass MethodB");
        }
    }

    class Fraction
    {
        private int numerator;
        private int denominator;

        public int Numerator
        {
            get { return numerator; }
            set { numerator = value; }
        }

        override public string ToString()
        {
            return ("data" + numerator.ToString());
        }
    }

    class Color
    {
        private string[] color = new string[5];
        public string this[int index]
        {
            get { return color[index]; }
            set { color[index] = value; }
        }
    }

    class Complex
    {
        private double realPart;                // 실수부 
        private double imagePart;             // 허수부 
        public Complex(double rVal, double iVal)
        {
            realPart = rVal;
            imagePart = iVal;
        }
        public static Complex operator +(Complex x1, Complex x2)
        {
            Complex x = new Complex(0, 0);
            x.realPart = x1.realPart + x2.realPart;
            x.imagePart = x1.imagePart + x2.imagePart;
            return x;
        }
        override public string ToString()
        {
            return "(" + realPart + "," + imagePart + "i)";
        }
    }
}

