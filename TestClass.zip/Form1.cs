﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void swap(Integer x, Integer y)
        {
            int temp;
            temp = x.i;
            x.i = y.i;
            y.i = temp;

            Console.WriteLine($"Swap in ==> x : {x.i} y : {y.i}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        void ParameterArray(params object[] obj)
        {
            for(int i = 0; i < obj.Length; i++)
            {
                Console.WriteLine(obj[i]);
            }
        }

        private void btnClassMake_Click(object sender, EventArgs e)
        {
            ParameterArray("ABC", "123", "가나다", "@#$", "<?>");
            ParameterArray("-----------","a");
            ParameterArray("-----------", "하나", "둘", "셋");

            /*            Integer x = new Integer(1);
                        Integer y = new Integer(2);

                        Console.WriteLine($"Swap Before ==> x : {x.i} y : {y.i}");
                        swap(x, y);
                        Console.WriteLine($"Swap After ==> x : {x.i} y : {y.i}");*/
        }
    }

    class Integer
    {
        public int i;
        public Integer(int i)
        {
            this.i = i;
        }
    }
}
